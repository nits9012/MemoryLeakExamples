//
//  SecondMemoryLeakExample.swift
//  MemoryLeakProblems
//
//  Created by Nitin Bhatt on 7/3/22.
//

import Foundation
import UIKit

class SecondMemoryLeakExample:UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData {[weak self] in
            self?.updateUI()
        }
    }
    
    deinit{
        print("deinit controller")
    }
    
    func updateUI(){
        print("update UI")
    }
    
    func loadData(completion: @escaping ()->()){
        let seconds = 10.0
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            completion()
        }
    }
}

