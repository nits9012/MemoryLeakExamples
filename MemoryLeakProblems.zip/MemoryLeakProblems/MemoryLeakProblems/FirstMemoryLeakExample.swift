//
//  FirstMemoryLeakExample.swift
//  MemoryLeakProblems
//
//  Created by Nitin Bhatt on 7/3/22.
//

import Foundation
import UIKit


class FirstMemoryLeakExample: UIViewController {
   
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
